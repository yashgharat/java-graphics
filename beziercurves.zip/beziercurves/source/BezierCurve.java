import java.awt.*;
import java.awt.geom.*;
import java.util.*;


public class BezierCurve{

    BezierCurve next;
    BezierCurve previous;
    
    BezierPoint firstPoint;
    BezierPoint selectedPoint;  // is null if curve is selected (i.e. draw in bold red)
    BezierPoint lastPoint;
	    
    //boolean show = true;
	//boolean isOver = false;
	//boolean isSelected = false;
    
    int N; // number of control points
	
	static double threshold = 5.0;
	
	Color color;
    
    public BezierCurve(){
		firstPoint = null;
		selectedPoint = null;
		lastPoint = null;
		N = 0;
		next = null;
		previous = null;
    }
    
       
    public BezierCurve( double x, double y ){
		firstPoint = new BezierPoint( x, y );
		selectedPoint = firstPoint;
		lastPoint = firstPoint;
		N = 1;
		next = null;
		previous = null;
    }


    public BezierCurve( BezierPoint point ){
		firstPoint = new BezierPoint( point );
		selectedPoint = firstPoint;
		lastPoint = firstPoint;
		N = 1;
		next = null;
		previous = null;
    }


    public BezierCurve( BezierCurve curve ){
		firstPoint = new BezierPoint( curve.firstPoint );
		selectedPoint = firstPoint;
		lastPoint = firstPoint;
		N = 1;

		BezierPoint tmp1 = firstPoint;
		BezierPoint tmp2 = curve.firstPoint.next;
		while ( tmp2 != null ){
			tmp1.next = new BezierPoint( tmp2 );
			tmp1.next.previous = tmp1;
			tmp1 = tmp1.next;
			tmp2 = tmp2.next;
			N++;
		}
		lastPoint = tmp1;
		next = null;
		previous = null;
    }


    public BezierCurve( String str ){
        StringTokenizer st = new StringTokenizer( str.replace('{',' '), "}" );
		firstPoint = new BezierPoint( st.nextToken() );
		BezierPoint tmp = firstPoint;
		N = 1;
		while ( st.hasMoreTokens() ){
			tmp.next = new BezierPoint( st.nextToken() );
			tmp.next.previous = tmp;
			tmp = tmp.next;
			N++;
		}
		lastPoint = tmp;
    }
	
	

	public double distance( Point p ){
		double out = 100;
		double tmp;
		double t = 0.0;
		double dot;
		double distAB;
		BezierPoint A = getPoint( 0.0 );
		BezierPoint B;
		
		while ( t <= 1.0 && out >= threshold ){
			// check distance from A
			tmp = getPoint( t ).distance(p.x,p.y);
			if ( tmp < out ) out = tmp;
			
			// check distanct from line segment AB
			B = getPoint( t + 0.01 );
			dot = A.subtract(B).dot(A.subtract(p));
			distAB = Math.pow( A.distance(B), 2 );
			if ( dot>0 && dot<distAB ){
				tmp = Math.sqrt( Math.pow( A.distance(p), 2 ) - dot*dot/distAB );
				if ( tmp < out ) out = tmp;
			}

			A = B;
			t += 0.01;
		}

		return out;
	}
    
    
    public void draw( Graphics2D g ){
		//Draw Lines
		BezierPoint old = firstPoint;
		BezierPoint tmp = firstPoint.next;
		if ( this == BezierCurvePanel.selectedCurve ){
			g.setColor( Color.gray );
			if ( BezierCurveApplet.showparametrization.isSelected() ){
				double T = BezierCurvePanel.T;
				BezierCurve curve = new BezierCurve();
				for ( int i=0; i<N-1; i++){
					while ( tmp != null ){
						g.draw( new Line2D.Double( old.x, old.y, tmp.x, tmp.y ) );
						curve.insertPoint( old.x + T*(tmp.x-old.x), old.y + T*(tmp.y-old.y) );
						old = tmp;
						tmp = tmp.next;
					}
					old = curve.firstPoint;
					tmp = old.next;
					curve = new BezierCurve();
				}
			} else {
				while ( tmp != null ){
					g.draw( new Line2D.Double( old.x, old.y, tmp.x, tmp.y ) );
					old = tmp;
					tmp = tmp.next;
				}
			}
		}

		//Draw Curve
		g.setColor( Color.black );
		g.setStroke( new BasicStroke( 2.0f ) );
		if ( this == BezierCurvePanel.selectedCurve && selectedPoint == null ){
			g.setColor( Color.red );
			g.setStroke( new BasicStroke( 4.0f ) );
		}
		old = firstPoint;
		if ( this == BezierCurvePanel.overCurve ){
			g.setStroke( new BasicStroke( 4.0f ) );
		}
		for ( double t=0.01; t<=1.0; t+=.01 ){
			tmp = getPoint( t );
			g.draw( new Line2D.Double( old.x, old.y, tmp.x, tmp.y ) );
			old = tmp;
		}
		g.draw( new Line2D.Double( old.x, old.y, lastPoint.x, lastPoint.y) );
	
        //Draw dots
		double r = BezierPoint.radius;
		g.setStroke( new BasicStroke( 1.0f ) );
		if ( this == BezierCurvePanel.selectedCurve ){
			tmp = firstPoint;
			g.setColor( Color.white );
			g.fill( new Ellipse2D.Double( tmp.x-r, tmp.y-r, 2*r, 2*r) );
			g.setColor( Color.black );
			if ( tmp == selectedPoint ) g.setColor( Color.red );
			g.draw( new Ellipse2D.Double( tmp.x-r, tmp.y-r, 2*r, 2*r) );
			tmp = tmp.next;

			while ( tmp != null ){
				g.setColor( Color.black );
				if ( tmp == selectedPoint ) g.setColor( Color.red );
				g.fill( new Ellipse2D.Double( tmp.x-r, tmp.y-r, 2*r, 2*r) );
				tmp = tmp.next;
			}
			
			tmp = BezierCurvePanel.overPoint;
			if ( tmp != null ){
				g.setColor( Color.black );
				if ( tmp == selectedPoint ) g.setColor( Color.red );
				g.draw( new Ellipse2D.Double( tmp.x-r-2, tmp.y-r-2, 2*r+4, 2*r+4) );
			}
        }
		if ( this == BezierCurvePanel.selectedCurve && BezierCurveApplet.showparametrization.isSelected() ){
			g.setColor( Color.red );
			tmp = getPoint( BezierCurvePanel.T );
			g.fill( new Ellipse2D.Double( tmp.x-r+1.5, tmp.y-r+1.5, 2*r-3, 2*r-3) );
		}
    }


    public BezierPoint getPoint( double t ){
		if ( N == 1 || t == 0.0 ){
			return firstPoint;
		} else if ( t == 1.000 ){
			return lastPoint;
		} else {
			// rewrite this using differences 
			BezierCurve tmpCurve = new BezierCurve( firstPoint.add(firstPoint.next.subtract(firstPoint).scale(t)) );
			BezierPoint tmpPoint = firstPoint.next;
			while ( tmpPoint.next != null ){
				tmpCurve.insertPoint( tmpPoint.add(tmpPoint.next.subtract(tmpPoint).scale(t)) );
				tmpPoint = tmpPoint.next;
			}
			return tmpCurve.getPoint( t );
		}
    }


    public void insertPoint( double x, double y ){
		if ( selectedPoint != null ){
			BezierPoint tmp = selectedPoint.next;
			selectedPoint.next = new BezierPoint( x, y );
			selectedPoint.next.previous = selectedPoint;
			selectedPoint.next.next = tmp;
			if ( tmp != null ){
				tmp.previous = selectedPoint.next;
			}
			if ( selectedPoint == lastPoint ) lastPoint = selectedPoint.next;
			selectedPoint = selectedPoint.next;
			N++;
		} else {
			if ( lastPoint != null ){
				lastPoint.next = new BezierPoint( x, y );
				lastPoint.next.previous = lastPoint;
				lastPoint = lastPoint.next;
				selectedPoint = lastPoint;
			} else {
				firstPoint = new BezierPoint( x, y );
				lastPoint = firstPoint;
				selectedPoint = lastPoint;
			}
			N++;
		}
    }


    public void insertPoint( BezierPoint point ){
		if ( selectedPoint != null ){
			BezierPoint tmp = selectedPoint.next;
			selectedPoint.next = new BezierPoint( point );
			selectedPoint.next.previous = selectedPoint;
			selectedPoint.next.next = tmp;
			if ( tmp != null ){
				tmp.previous = selectedPoint.next;
			}
			if ( selectedPoint == lastPoint ) lastPoint = selectedPoint.next;
			selectedPoint = selectedPoint.next;
			N++;
		} else {
			if ( lastPoint != null ){
				lastPoint.next = new BezierPoint( point );
				lastPoint.next.previous = lastPoint;
				lastPoint = lastPoint.next;
			} else {
				firstPoint = new BezierPoint( point);
				lastPoint = firstPoint;
				selectedPoint = lastPoint;
			}
			N++;
		}
    }


    public int length(){
        return N;
    }


    public void removePoint(){
		if ( selectedPoint != null ){
			if ( selectedPoint.previous != null ){       // not the first point
				selectedPoint.previous.next = selectedPoint.next;
				if ( selectedPoint.next != null ){		// not the last point either
					selectedPoint.next.previous = selectedPoint.previous;
				}
				if ( selectedPoint == lastPoint ) lastPoint = selectedPoint.previous;
				selectedPoint = selectedPoint.previous;
			} else if ( selectedPoint.next != null ){    // first point among at least two points
				firstPoint = selectedPoint.next;
				firstPoint.previous = null;
				selectedPoint = firstPoint;
			} else {				    // only one point 
			// do nothing
			// curve will be erased next time it is drawn
			}
			N--;
		}
    }
       

    public String toString(){
		String out = "{";
		BezierPoint tmp = firstPoint;
		while ( tmp.next != null ){
			out += tmp.toString() + ", ";
			tmp = tmp.next;
		}

		out+= tmp.toString() + "}";
		return out;
    }


    public void translate( double dx, double dy ){
		BezierPoint tmp = firstPoint;
		while ( tmp != null ){
			tmp.translate( dx, dy );
			tmp = tmp.next;
		}
    }
    
    
    // returns first control point that is within 5 pixels of (x,y)
    // returns null if no such control point exists
    public BezierPoint whichPoint( int x, int y ){
        BezierPoint out = null;
		BezierPoint tmp = firstPoint;

        while ( tmp != null && out == null ){
			if ( tmp.distance( x, y ) < 6 ){
				out = tmp;
			}
			tmp = tmp.next;
		}
        return out;
    }
}