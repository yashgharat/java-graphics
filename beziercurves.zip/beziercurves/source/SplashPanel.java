import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class SplashPanel extends JPanel implements MouseListener,Runnable{
	
	double w;
	double h;

	public boolean newBackground = true;
	public boolean active = true;

	BezierCurveApplet applet;
	
	BasicStroke thin = new BasicStroke( 4.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND );
	BasicStroke thick = new BasicStroke( 5.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND );

	Thread thread;
		
	double[][] xPoints = new double[4][4];  // each column determines a single control point
	double[][] yPoints = new double[4][4];
	
	double[] red = new double[4];
	double[] green = new double[4];
	double[] blue = new double[4];

	BezierCurve firstCurve;

	public SplashPanel( BezierCurveApplet applet ){
		setBackground( Color.white );
		this.applet = applet;
		
		for ( int i=0; i<4; i++ ){
			for ( int j=0; j<4; j++ ){
				xPoints[i][j] = Math.random()*400;
				yPoints[i][j] = Math.random()*100;
			}
			red[i] = Math.random();
			green[i] = Math.random();
			blue[i] = Math.random();
		}
		
		addMouseListener( this );

		//start();
	}
	
	public double bernstein( double x, double y, double z, double t ){
		return x + 2*t*(y-x) + t*t*(z-2*y+x);
	}

	public double bernstein( double w, double x, double y, double z, double t ){
		return w + 3*t*(x-w) + 3*t*t*(y-2*x+w) + t*t*t*(z-3*y+3*x-w);
	}
	
	public double minmax( double s, double t ){
		return Math.max( 0, Math.min( s,t ) );
	}

	public void newCurve( double t ){
		BezierCurve tmp = firstCurve;
		double x = bernstein( xPoints[0][0], xPoints[1][0], xPoints[2][0], xPoints[3][0] , t );
		double y = bernstein( yPoints[0][0], yPoints[1][0], yPoints[2][0], yPoints[3][0] , t );
		BezierCurve curve = new BezierCurve(x,y);
		for ( int i=1; i<4; i++ ){
			x = bernstein( xPoints[0][i], xPoints[1][i], xPoints[2][i], xPoints[3][i] , t );
			y = bernstein( yPoints[0][i], yPoints[1][i], yPoints[2][i], yPoints[3][i] , t );
			curve.insertPoint( x, y);
		}
		double r = bernstein( red[0], red[1], red[2], red[3], t );
		double g = bernstein( green[0], green[1], green[2], green[3], t );
		double b = bernstein( blue[0], blue[1], blue[2], blue[3], t );
		curve.color = new Color( (float)r, (float)g, (float)b );
		curve.next = tmp;
		if ( tmp != null ) tmp.previous = curve;
		firstCurve = curve;
	}


	public void paintComponent( Graphics graphics ){
		w = getWidth();
		h = getHeight();

		Graphics2D g = (Graphics2D)graphics;
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
		g.setColor( getBackground() );
		g.fill( new Rectangle2D.Double( 0, 0, w, h ) );

		BezierCurve tmp = firstCurve;
		BezierPoint p;
		BezierPoint q;
		BezierPoint r;
		BezierPoint s;
		int I=0;
		for ( int i=0; i<40; i++ ){
			if ( tmp.next != null ){
				tmp = tmp.next;
				I++;
			}
		}
		tmp.next = null;
		g.setStroke( thin );
		double d;
		for ( int i=I; i>0; i-- ){
			p = tmp.firstPoint;
				//d = Math.sqrt((w/2 - p.x)*(w/2 - p.x) + (h/2 - p.y)*(h/2 - p.y));
				//p.x += (w/2 - p.x)/d;
				//p.y += (h/2 - p.y)/d;
				p.y--;
			q = p.next;
				//d = Math.sqrt((w/2 - q.x)*(w/2 - q.x) + (h/2 - q.y)*(h/2 - q.y));
				//q.x += (w/2 - q.x)/d;
				//q.y += (h/2 - q.y)/d;
				q.y--;
			r = q.next;
				//d = Math.sqrt((w/2 - r.x)*(w/2 - r.x) + (h/2 - r.y)*(h/2 - r.y));
				//r.x += (w/2 - r.x)/d;
				//r.y += (h/2 - r.y)/d;
				r.y--;
			s = r.next;
				//d = Math.sqrt((w/2 - s.x)*(w/2 - s.x) + (h/2 - s.y)*(h/2 - s.y));
				//s.x += (w/2 - s.x)/d;
				//s.y += (h/2 - s.y)/d;
				s.y--;
			g.setColor( new Color(tmp.color.getRed(),tmp.color.getGreen(),tmp.color.getBlue(),(int)(255-255*i/40.0)) );
			g.draw( new CubicCurve2D.Double(p.x,p.y,q.x,q.y,r.x,r.y,s.x,s.y) );
			if ( tmp.previous != null ) tmp = tmp.previous;
		}
		p = tmp.firstPoint;
		q = p.next;
		r = q.next;
		s = r.next;
		g.setColor( Color.black );
		g.setStroke( thick );
		g.draw( new CubicCurve2D.Double(p.x,p.y,q.x,q.y,r.x,r.y,s.x,s.y) );
		
		// Draw "Click Here to Begin"
		g.setColor( new Color( 128,128,128,120 ) );
		g.setFont( new Font("Helvetica",Font.BOLD,18) );
		String str = "CLICK ANYWHERE TO BEGIN";
		g.drawString( str, (int)(w-g.getFontMetrics().stringWidth(str)-5), (int)(h-5) );
	}
	
	
	public void randomControlPoints(){
		for ( int j=0; j<4; j++ ){
			xPoints[0][j] = xPoints[3][j];
			xPoints[1][j] = 2*xPoints[3][j]-xPoints[2][j];

			yPoints[0][j] = yPoints[3][j];
			yPoints[1][j] = 2*yPoints[3][j]-yPoints[2][j];

		}
		red[0] = red[3];
		//red[1] = 2*red[3] - red[2]; // could be outside the interval [0,1]
			
		green[0] = green[3];
		//green[1] = 2*green[3] - green[2];
			
		blue[0] = blue[3];
		//blue[1] = 2*blue[3] - blue[2];

		
		for ( int i=2; i<4; i++ ){
			for ( int j=0; j<4; j++ ){
				xPoints[i][j] = Math.random()*w;
				yPoints[i][j] = Math.random()*h;
			}
			red[i] = Math.random();
			green[i] = Math.random();
			blue[i] = Math.random();
		}
	}
	
	
	public void run(){
		long time = Calendar.getInstance().getTimeInMillis()/5000;
		
		while ( active ){
			if ( Calendar.getInstance().getTimeInMillis()/5000 > time ){
				time = Calendar.getInstance().getTimeInMillis()/5000;
				randomControlPoints();
			}
			newCurve( Calendar.getInstance().getTimeInMillis()/5000.0 - time );
			try {
				Thread.sleep(75);
			} catch (InterruptedException e){
			}
			repaint();
		}
    }
	
	public void start(){
		active = true;
		thread = new Thread(this);
		thread.start();
	}

	public void mouseClicked( MouseEvent me ){
		active = false;
		applet.showFrame();
	}

	public void mouseEntered( MouseEvent me ){
	}

	public void mouseExited( MouseEvent me ){
	}

	public void mousePressed( MouseEvent me ){
	}

	public void mouseReleased(MouseEvent me){
	}	
}